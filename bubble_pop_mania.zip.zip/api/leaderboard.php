<?php
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/../config/db.php';
$stmt = $pdo->query('SELECT player_name, score, created_at FROM scores ORDER BY score DESC, created_at ASC LIMIT 10');
echo json_encode($stmt->fetchAll());
