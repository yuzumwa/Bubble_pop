<?php
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'POST required']); exit;
}
require_once __DIR__ . '/../config/db.php';
$input = json_decode(file_get_contents('php://input'), true);
$name = trim((string)($input['player_name'] ?? ''));
$score = filter_var($input['score'] ?? null, FILTER_VALIDATE_INT);
if ($name === '' || mb_strlen($name) > 40 || $score === false || $score < 0 || $score > 1000000) {
    http_response_code(422); echo json_encode(['error' => 'Invalid player name or score']); exit;
}
$stmt = $pdo->prepare('INSERT INTO scores (player_name, score) VALUES (:name, :score)');
$stmt->execute(['name' => $name, 'score' => $score]);
echo json_encode(['success' => true, 'id' => (int)$pdo->lastInsertId()]);
